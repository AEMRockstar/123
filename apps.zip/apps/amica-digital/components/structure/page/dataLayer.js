"use strict";

use(function () {
	
	var CONST = {
		CATEGORY_PROP: "category",
		USER_AGENT_PROP: "User-Agent"
	};
	
    var data = {}; 
       
    data.pageName = currentPage.getName() || currentPage.getTitle() ;
    data.pageCategory = inheritedPageProperties.get(CONST.CATEGORY_PROP, "");
    data.device = request.getHeader(CONST.USER_AGENT_PROP);
    
    data.CONST = CONST;
    
    return data;
});
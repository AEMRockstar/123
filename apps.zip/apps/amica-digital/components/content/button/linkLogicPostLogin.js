"use strict";
use(function () {

    var type = granite.resource.properties["linkTypePostLogin"];
    var linkPostLogin = granite.resource.properties["linkPostLogin"]+"";
    
  if(linkPostLogin.length>0){
    	
	    var isTel = linkPostLogin.startsWith('tel') ;
	    var isJavas =  linkPostLogin.startsWith("javas");
	    var isMailto = linkPostLogin.startsWith("mailto"); 
	    var webUrl = linkPostLogin.startsWith("http");
	    var html = linkPostLogin.includes(".html");
	    var isOther = linkPostLogin.endsWith(".pdf") || linkPostLogin.endsWith(".jsp");
    }
    
    if(type == 'directorLinkPostLogin'){
    	
    	linkPostLogin = "javascript:Director.directRequest('" + granite.resource.properties["directorLinkPostLogin"].toString()+ "'); " ;   
    	
    } else if (!(isTel || isJavas || isMailto || isOther || webUrl || html)) {
    	
    	linkPostLogin = granite.resource.properties["linkPostLogin"]+".html";
    }   
    return { 
    	
        urlLinkPostLogin : linkPostLogin
    };
});
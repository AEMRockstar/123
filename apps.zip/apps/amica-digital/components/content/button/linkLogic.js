"use strict";
use(function () {

    var type = granite.resource.properties["linkType"]+"";
    var link = granite.resource.properties["link"]+"";

    if(link.length>0){
    	
	    var isTel = link.startsWith("tel") ;
	    var isJavas =  link.startsWith("javas");
	    var isMailto = link.startsWith("mailto");  
        var webUrl = link.startsWith("http");
        var html = link.includes(".html");
	    var isOther = link.endsWith(".pdf") || link.endsWith(".jsp");
    }


    if(type == 'directorLink'){
    	
     link = "javascript:Director.directRequest('" + granite.resource.properties["directorlink"].toString()+ "'); " ; 

    } else if (!(isTel || isJavas || isMailto || isOther || webUrl || html )) {
    	
    	link = granite.resource.properties["link"]+".html";
    }   
    return { 
        urlLink : link

    };
});


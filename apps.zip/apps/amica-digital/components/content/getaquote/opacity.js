"use strict";
use(function () {

    var opacity = granite.resource.properties["opacity"];
    
    opacity = opacity/100; 
  
    return { 
    	opacity : opacity

    };
});


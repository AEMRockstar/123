"use strict";  
  
use([], function () {  
    var tempArr = resource.path.toString().split("/");
    var localId = "";
    if(tempArr.length > 0)
    {
    	localId = tempArr[tempArr.length-1];
    }
	var  uniqueID = "uniqueID" + localId;

    return uniqueID;  
});  









var Ejst = {};

Ejst.x2 = {};

Ejst.x2.toggleFieldSet = function(operator) {
    var panel = operator.findParentByType('panel');
    var showWidgetId =operator.getValue();

    for(var i = 0;i < 3; i++){
    	var fieldSet = panel.findByType('dialogfieldset')[i];
    	if (showWidgetId == fieldSet.getItemId()) {
            fieldSet.show();
            panel.doLayout();
        } else {
            fieldSet.hide();
            fieldSet.items.each(function(field) {
                try {
                    field.setValue();
                } catch (e) {
                }
            });
        }
    }
};
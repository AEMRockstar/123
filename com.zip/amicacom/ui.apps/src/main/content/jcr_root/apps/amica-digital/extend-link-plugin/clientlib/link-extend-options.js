(function($) {
    "use strict";

    var _ = window._,
        Class = window.Class,
        CUI = window.CUI,
        REL_FIELD = "rel",
        METRICS_ID_FIELD = "metrics-id",
        PRIORITY_FIELD = "priority",
        ACTION_FIELD = "dataaction",
        RTE_LINK_DIALOG = "rtelinkdialog",
        PRIORITY_TEXT = "cmsTrack",
        DIRECTOR_LINK = "directorLink",
        WEBURL_LINK = "webURL_LINK";

    if (CUI.rte.ui.cui.CuiDialogHelper.extended) {
        return;
    }

    var ExtendLinkBaseDialog = new Class({
        extend: CUI.rte.ui.cui.CQLinkBaseDialog,

        toString: "ExtendLinkBaseDialog",

        initialize: function(config) {
            this.superClass.initialize.call(this, config);

            this.$rteDialog = this.$container.find("[data-rte-dialog=link]");
            $("foundation-autocomplete[name=href]").parents(".rte-dialog-columnContainer").removeClass("required")

            this.$rteDialog.find(".rte-dialog-columnContainer:first").before(getLinkRelOptionsHtml());
            this.$rteDialog.find(".rte-dialog-columnContainer:first").after(getDirectorLinkRelOptionsHtml());
            this.$rteDialog.find(".rte-dialog-columnContainer:last").before(getMetricsId());
            this.$rteDialog.find(".rte-dialog-columnContainer:last").before(getPriority());
		},
        /* Fires when the OK button is clicked on hyperlink modal dialog */
        dlgToModel: function() {
            this.superClass.dlgToModel.call(this);

            var metricsIdField = this.getFieldByType(METRICS_ID_FIELD);
            var priorityField = this.getFieldByType(PRIORITY_FIELD);

            if ((_.isEmpty(metricsIdField)) || (_.isEmpty(metricsIdField.val()))) {
                return;
            }

            var dataActionVal = metricsIdField.val();

            var priorityVal = priorityField[0].checked ? true : false;
            priorityField.on('change', function setPriorityValue(event) {
                priorityVal = event.currentTarget.checked ? true : false;
            });

            if (priorityVal) {
                dataActionVal += "." + PRIORITY_TEXT;
            }

            this.objToEdit.attributes[ACTION_FIELD] = dataActionVal;
			
			var linkSelection = $(".amica-rte-link-selection").find('input').attr('value');

            var hrefField = $('foundation-autocomplete[name=href]');
            var directorLinkField = this.getFieldByType(DIRECTOR_LINK);
            if (_.isEmpty(hrefField.val()) && _.isEmpty(directorLinkField.val())) {
                alert("Please enter either weburl or director link");
                return;
            }

            if (linkSelection === "Weburl" && hrefField) {
                var href = hrefField.val();
                if (href) {
                    this.objToEdit.href = href;
                }
            }

            if (linkSelection === "Director Link" && directorLinkField) {
                var directorLinkVal = directorLinkField.val();
                if (directorLinkVal) {
                    this.objToEdit.attributes["directorLink"] = directorLinkVal;
                    this.objToEdit.href = "javascript:Director.directRequest('" + directorLinkVal + "');";
                }
            }
        },



        /* Fires when the modal hyperlink dialog is opened */
        dlgFromModel: function() {
            this.superClass.dlgFromModel.call(this);
			
            if (_.isEmpty(this.objToEdit.attributes)) {
                return;
            }
			
			var hrefField = $('foundation-autocomplete[name=href]');
            var directorLinkField = this.getFieldByType(DIRECTOR_LINK);
			//setting empty value for when the href value is empty
			/*if (hrefField) {
                var href = hrefField.val();
                if (href) {
                    this.objToEdit.href = href;
                }else{
					this.objToEdit.href = "";
				}
            }
			//setting empty value for when the directorLinkField value is empty
            if (directorLinkField) {
                var directorLinkVal = directorLinkField.val();
				var hrefFieldVal  = hrefField.val();
                if (hrefFieldVal) {
					if(hrefFieldVal && hrefFieldVal.substring(0,4) == "java") {
                        hrefField.val("");
                    }
				}
            }*/

            var dataActionVal = this.objToEdit.attributes[ACTION_FIELD];

            var metricsIdVal = dataActionVal.split(".")[0];

            if (_.isEmpty(metricsIdVal)) {
                return;
            }

            var metricsId = this.$rteDialog.find("[data-type='metrics-id']")[0];
            metricsId.value = metricsIdVal;

            var priority = this.$rteDialog.find("[data-type='priority']")[0];

            if (dataActionVal.indexOf(PRIORITY_TEXT) >= 0) {
                priority.set("checked", true);
            } else {
                priority.set("checked", false);
            }

            var directorLinkValue = this.objToEdit.attributes['directorLink'];
            if (_.isEmpty(directorLinkValue)) {
                return;
            }

            var directorLinkSelect = this.$rteDialog.find("[data-type='directorLink']")[0];
            directorLinkSelect.items.getAll().forEach(function(elem) {
                elem.selected = (elem.value === directorLinkValue);
            });
        }
    });

    CUI.rte.ui.cui.CuiDialogHelper = new Class({
        extend: CUI.rte.ui.cui.CuiDialogHelper,

        toString: "CuiDialogHelper",

        instantiateDialog: function(dialogConfig) {
            var type = dialogConfig.type;

            if (type !== RTE_LINK_DIALOG) {
                this.superClass.instantiateDialog.call(this, dialogConfig);
                return;
            }

            var $editable = $(this.editorKernel.getEditContext().root),
                $container = CUI.rte.UIUtils.getUIContainer($editable),
                dialog = new ExtendLinkBaseDialog();

            dialog.attach(dialogConfig, $container, this.editorKernel);

            return dialog;
        }
    });

    function getLinkRelOptionsHtml() {
        var html = "<div class='rte-dialog-columnContainer'>" +
            "<div class='rte-dialog-column'>" +
            "<coral-select class='amica-rte-link-selection' data-type='rel' placeholder='Choose \"link\" value'>";

        var options = ["Weburl", "Director Link"];

        _.each(options, function(option) {
            html = html + getOptionHtml(option);
        });

        html = html + "</coral-select></div></div>";

        return html;

        function getOptionHtml(option) {
			if(option === "Weburl"){
				return "<coral-select-item selected>" + option + "</coral-select-item>";
			}else{
				return "<coral-select-item>" + option + "</coral-select-item>";
			}
        }
    }
	$(".amica-rte-director-link").find('input').attr('value')
    $(document).on('change', '.amica-rte-link-selection', function() {
        var value = "";
        if ($(this).find('input').length > 0 && $(this).find('input').attr('value')) {
            value = $(this).find('input').attr('value');
            if (value === "Weburl") {
                $(".amica-rte-director-link").parents(".rte-dialog-columnContainer").addClass("hide")
                $("foundation-autocomplete[name=href]").parents(".rte-dialog-columnContainer").removeClass("hide")
            } else if (value === "Director Link") {
                $(".amica-rte-director-link").parents(".rte-dialog-columnContainer").removeClass("hide")
                $("foundation-autocomplete[name=href]").parents(".rte-dialog-columnContainer").addClass("hide")
            }
        }
        $(".amica-rte-director-link");
        $("foundation-autocomplete[name=href]");
    });
   


    function getMetricsId() {
        var html = "<div class='rte-dialog-columnContainer'>" +
            "<div class='rte-dialog-column'>" +
            "<input is='coral-textfield' class='coral-Form-field' data-type='metrics-id' placeholder='Enter the MetricsId value' name='metrics-id'>";

        html = html + "</div></div>";

        return html;
    }

    function getPriority() {
        var html = "<div class='rte-dialog-columnContainer'>" +
            "<div class='rte-dialog-column'>" +
            "<coral-checkbox class='coral-Form-field' name='priority' data-type='priority'>Priority Link</coral-checkbox>";

        html = html + "</div></div>";

        return html;
    }

    function getDirectorLinkRelOptionsHtml() {

        var html = "<div class='rte-dialog-columnContainer hide'>" +
            "<div class='rte-dialog-column'>" +
            "<coral-select class='amica-rte-director-link' data-type='directorLink' placeholder='Choose \"director\" value'>";


        $.ajax({
            url: "/etc/acs-commons/lists/director_list/_jcr_content.list.json",
            dataType: 'json',
            async: false,
            success: function(data) {
                $.each(data, function(i, value) {
                    html = html + getOptionHtml(value);
                });
            }
        });

        html = html + "</coral-select></div></div>";

        return html;

        function getOptionHtml(option) {
            return "<coral-select-item value='" + option.value + "' >" + option.text + "</coral-select-item>"
        }

    }

    CUI.rte.ui.cui.CuiDialogHelper.extended = true;
})(jQuery);
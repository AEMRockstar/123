"use strict";
use(function () {

    var type = granite.resource.properties["linkTypeRetriveInfo"]+"";
    var link = granite.resource.properties["linkRetriveInfo"]+"";

    if(link.length>0){
    	
	    var isTel = link.startsWith('tel') ;
	    var isJavas =  link.startsWith("javas");
	    var isMailto = link.startsWith("mailto");  
        var webUrl = link.startsWith("http");
        var html = link.includes(".html"); 
	    var isOther = link.endsWith(".pdf") || link.endsWith(".jsp");
    }


    if(type == 'directorLinkRetriveInfo'){
    	
    	retriveLinkInfolink = "javascript:Director.directRequest('" + granite.resource.properties["directorlinkRetriveInfo"].toString()+ "'); " ; 

    } else if (!(isTel || isJavas || isMailto || isOther || webUrl || html)) {
    	
    	retriveLinkInfolink = granite.resource.properties["linkRetriveInfo"]+".html";
    }   
    return { 
        urLinkRetriveInfo : retriveLinkInfolink

    };
});


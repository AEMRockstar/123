"use strict";
use(function () {

	var pageTitle = granite.resource.properties["pageTitle"];
    var searchPlaceholder = granite.resource.properties["searchPlaceholder"];
    var searchResultsHeading = granite.resource.properties["searchResultsHeading"];
    var quicklinksResultsHeading = granite.resource.properties["quicklinksResultsHeading"];
    var noResultsText = granite.resource.properties["noResultsText"];
    var resultCountSingular = granite.resource.properties["resultCountSingular"];
    var resultCountMulti = granite.resource.properties["resultCountMulti"];
    var searchButtonLabel = granite.resource.properties["searchButtonLabel"];
    
    var enableSynonyms = granite.resource.properties["enableSynonyms"];
    var hideSpellcheck = granite.resource.properties["hideSpellcheck"];
    var displayquicklinks = granite.resource.properties["displayquicklinks"];
    var displayDescription = granite.resource.properties["displayDescription"];

    return {

    	enableSynonyms : enableSynonyms,
    	hideSpellcheck : hideSpellcheck,
    	displayquicklinks : displayquicklinks,
    	displayDescription : displayDescription,
    	searchPlaceholder : searchPlaceholder,
    	searchResultsHeading : searchResultsHeading,
    	quicklinksResultsHeading : quicklinksResultsHeading,
    	searchButtonLabel : searchButtonLabel,
    	noResultsText : noResultsText,
    	resultCountSingular : resultCountSingular,
    	resultCountMulti : resultCountMulti,
    	pageTitle : pageTitle

    };
});
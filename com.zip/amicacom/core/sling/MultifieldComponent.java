package com.amica.adc.amicacom.core.sling;

import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;
 
 
@Model(adaptables = Resource.class)
public class MultifieldComponent{
	
	@Inject
    @Optional
    public Resource itemsIn;
	
	@Inject
    @Optional
    public Resource items1;
	
	@Inject
    @Optional
    public Resource items2;
	
	@Inject
    @Optional
    public Resource items3;
	
	@Inject
    @Optional
    public Resource items4;
	

}

package com.amica.adc.amicacom.core.sling;

public class MultifieldModel {
	
	private String file;
	
	private String alt;
	
	private String newWindow;
	
	private String linkType;
	
	private String link;
	
	private String directorlink;
	
	private String caption;
	
	private String tootltip;
	
	private String metricsIDField;
	
	private String icon;
	
	private String linkTitle;
	
	private String isPriority;
	
	private String bold;
	
	private String linkPadding;
	
	private String hr;
	
	private String hrPadding;


	public String getFile() {
		return file;
	}

	public void setFile(String file) {
		this.file = file;
	}

	public String getAlt() {
		return alt;
	}

	public void setAlt(String alt) {
		this.alt = alt;
	}
	
	public String getIsPriority() {
		return isPriority;
	}

	public void setIsPriority(String isPriority) {
		this.isPriority = isPriority;
	}

	public String getNewWindow() {
		return this.newWindow;
	}

	public void setNewWindow(String newWindow) {
		this.newWindow = newWindow;
	}

	public String getLinkType() {
		return this.linkType;
	}

	public void setLinkType(String linkType) {
		this.linkType = linkType;
	}

	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}

	public String getDirectorlink() {
		return directorlink;
	}

	public void setDirectorlink(String directorlink) {
		this.directorlink = directorlink;
	}

	public String getCaption() {
		return caption;
	}

	public void setCaption(String caption) {
		this.caption = caption;
	}

	public String getTootltip() {
		return tootltip;
	}

	public void setTootltip(String tootltip) {
		this.tootltip = tootltip;
	}

	public String getMetricsIDField() {
		return metricsIDField;
	}

	public void setMetricsIDField(String metricsIDField) {
		this.metricsIDField = metricsIDField;
	}

	public String getIcon() {
		return icon;
	}

	public void setIcon(String icon) {
		this.icon = icon;
	}	
	
	public String getLinkTitle() {
		return linkTitle;
	}

	public void setLinkTitle(String linkTitle) {
		this.linkTitle = linkTitle;
	}

	public String getBold() {
		return bold;
	}

	public void setBold(String bold) {
		this.bold = bold;
	}

	public String getLinkPadding() {
		return linkPadding;
	}

	public void setLinkPadding(String linkPadding) {
		this.linkPadding = linkPadding;
	}

	public String getHr() {
		return hr;
	}

	public void setHr(String hr) {
		this.hr = hr;
	}

	public String getHrPadding() {
		return hrPadding;
	}

	public void setHrPadding(String hrPadding) {
		this.hrPadding = hrPadding;
	}
	
}

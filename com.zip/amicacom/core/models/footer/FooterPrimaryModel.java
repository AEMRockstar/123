package com.amica.adc.amicacom.core.models.footer;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import com.amica.adc.amicacom.core.common.enums.PageLocation;
import com.amica.adc.amicacom.core.models.LinkListModel;
import com.amica.adc.amicacom.core.services.AnalyticsService;
import com.day.cq.commons.inherit.InheritanceValueMap;
import com.day.cq.wcm.api.Page;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceUtil;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;
import org.apache.sling.models.annotations.Via;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Model ( adaptables = {SlingHttpServletRequest.class, Resource.class} )
public class FooterPrimaryModel {
	
	public static final Logger LOGGER = LoggerFactory.getLogger(FooterPrimaryModel.class);
	
/*	@SlingObject
	private SlingHttpServletRequest request;*/
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String metricsId;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private Boolean priority;
	
	@Inject @Optional @Via("resource")
	private Resource itemsIn;
	
	@OSGiService
	AnalyticsService analyticsService;
	
	@Inject
    private Page resourcePage;
	
/*	@Inject
    private InheritanceValueMap pageProperties;*/
	
	@Inject 
    private Page currentPage;
	
	private String dataAction;	

	private List<LinkListModel> links = new ArrayList<LinkListModel>();
	
	@PostConstruct
	public void init() {
		
		LOGGER.debug("Footer Primary Model initialization -- START");
		
		if(StringUtils.isNotEmpty(metricsId)) {
			
			dataAction = analyticsService.getDataIdVal(PageLocation.FOOTER.getPageSection(), metricsId, priority);
		}
		
		
		if (itemsIn!=null && !ResourceUtil.isNonExistingResource(itemsIn) && itemsIn.hasChildren()) {
			LOGGER.debug("Child resources present");
			Iterator<Resource> iterator = itemsIn.listChildren();
				while(iterator.hasNext()){
					Resource childLinkResource = iterator.next();
					LinkListModel item = childLinkResource.adaptTo(LinkListModel.class);
					
					LOGGER.debug("item-dataaction value-->"+item.getDataAction());
					links.add(item);
					
				}
		}
		
		LOGGER.debug("Footer Primary Model initialization -- END");
	}


	public Resource getItemsIn() {
		return itemsIn;
	}

	
	public String getDataAction() {
		return dataAction;
	}


	public List<LinkListModel> getLinks() {
		return links;
	}


	public Page getResourcePage() {
		return resourcePage;
	}


	/*public Page getCurrentPage() {
		return currentPage;
	}*/
	
}

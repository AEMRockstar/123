package com.amica.adc.amicacom.core.models;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import com.amica.adc.amicacom.core.services.AdaptiveImageService;
import com.amica.adc.amicacom.core.services.AnalyticsService;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Model ( adaptables = Resource.class)
public class ImageModel {
	
	public static final Logger LOGGER = LoggerFactory.getLogger(ImageModel.class);
	
	@SlingObject
	Resource resource;

	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String fileReference;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String linkType;	
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String newWindow;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String alt;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String tooltip;
	
	@Inject @Optional
	private String metricsId;
	
	@Inject @Optional
	private Boolean priority;
	
	@Inject
	AnalyticsService analyticsService;
	
	@Inject
	AdaptiveImageService adaptiveImageService;
	
	private String dataAction;
	
	@PostConstruct
	public void init() {
		
		LOGGER.debug("Button Model initialization -- START");
		
		dataAction = analyticsService.getDataIdVal(metricsId, priority);

		LOGGER.debug("Button Model initialization -- END");
		
	}

	public String getDataAction() {
		return dataAction;
	}

	public String getFileReference() {
		return fileReference;
	}

	public String getLinkType() {
		return linkType;
	}
	
	public String getNewWindow() {
		return newWindow;
	}

	public String getAlt() {
		return alt;
	}

	public String getTooltip() {
		return tooltip;
	}
	
}

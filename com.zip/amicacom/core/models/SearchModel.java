package com.amica.adc.amicacom.core.models;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import com.amica.adc.amicacom.core.common.constants.CommonConstants;
import com.amica.adc.amicacom.core.common.constants.SearchConstants;
import com.amica.adc.amicacom.core.search.SearchConfigurationService;
import com.amica.adc.amicacom.core.services.AnalyticsService;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Model ( adaptables = Resource.class)
public class SearchModel {
	
	public static final Logger LOGGER = LoggerFactory.getLogger(SearchModel.class);
	
	@SlingObject
	Resource resource;
	
	@Inject
	SearchConfigurationService searchConfigService;

	private String searchResultPagePath;
		
	@PostConstruct
	public void init() {
		
		LOGGER.debug("Search Result  Model initialization -- START");
		
		searchResultPagePath = searchConfigService.getSearchResultsPagePath();

		LOGGER.debug("Search Result Model initialization -- END");
		
	}

	public String getSearchResultPagePath() {
		return searchResultPagePath;
	}
	
}

package com.amica.adc.amicacom.core.models;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import com.amica.adc.amicacom.core.common.constants.CommonConstants;
import com.amica.adc.amicacom.core.common.enums.PageLocation;
import com.amica.adc.amicacom.core.services.AnalyticsService;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Model ( adaptables = Resource.class)
public class LinkListModel {
	
	public static final Logger LOGGER = LoggerFactory.getLogger(LinkListModel.class);
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String title;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String linkType;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String link;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String directorlink;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String newWindow;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String alt;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String tooltip;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String metricsId;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private Boolean priority;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String file;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String label;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String icon;
	
	@Inject
	AnalyticsService analyticsService;
	
	private String dataAction;
	
	@PostConstruct
	public void init() {
		
		LOGGER.debug("Link List Model initialization -- START");
		
		dataAction = analyticsService.getDataIdVal(PageLocation.FOOTER.getPageSection(), metricsId, priority);
		
		LOGGER.debug("dataAction value being set for metricsID->"+metricsId +"-->"+ dataAction);
		LOGGER.debug("Link List Model initialization -- END");
		
		link = getUrl(link, linkType );
		
	}

	public String getDataAction() {
		return dataAction;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getLinkType() {
		return linkType;
	}

	public void setLinkType(String linkType) {
		this.linkType = linkType;
	}

	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}

	public String getDirectorlink() {
		return directorlink;
	}

	public void setDirectorlink(String directorlink) {
		this.directorlink = directorlink;
	}

	public String getNewWindow() {
		return newWindow;
	}

	public void setNewWindow(String newWindow) {
		this.newWindow = newWindow;
	}

	public String getMetricsId() {
		return metricsId;
	}

	public void setMetricsId(String metricsId) {
		this.metricsId = metricsId;
	}

	public Boolean getPriority() {
		return priority;
	}

	public void setPriority(Boolean priority) {
		this.priority = priority;
	}

	public String getAlt() {
		return alt;
	}

	public String getTooltip() {
		return tooltip;
	}

	public String getFile() {
		return file;
	}

	public String getLabel() {
		return label;
	}

	public String getIcon() {
		return icon;
	}
	
	public String getUrl(String link, String linkType ) {
        
		String updatedLink = "";
		Boolean noExtension =  false;
        
		if(StringUtils.startsWith(link, CommonConstants.LINK_PROTOCOL_HTTP) || StringUtils.startsWith(link, CommonConstants.LINK_PROTOCOL_TEL) || 
				StringUtils.startsWith(link, CommonConstants.LINK_PROTOCOL_MAIL) || StringUtils.startsWith(link, CommonConstants.LINK_PROTOCOL_JAVASCRIPT) || 
				StringUtils.contains(link, CommonConstants.EXTENSION_HTML) || StringUtils.endsWith(link,CommonConstants.EXTENSION_PDF)  ||
				StringUtils.endsWith(link,CommonConstants.EXTENSION_JSP) ) {
			
			noExtension = true;
		}
		
        if(StringUtils.equalsIgnoreCase(linkType, CommonConstants.DIRECTOR_LINK_TYPE_TEXT) || noExtension) {
        	return link;
        	
        } else {
        	updatedLink =	link + CommonConstants.EXTENSION_HTML;
        	
        }
        
        return updatedLink;      
    }
	
}

package com.amica.adc.amicacom.core.models;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import com.amica.adc.amicacom.core.services.AnalyticsService;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Model ( adaptables = Resource.class)
public class LocalNavLinkDetailsModel {
	
	public static final Logger LOGGER = LoggerFactory.getLogger(LocalNavLinkDetailsModel.class);
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String bold;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String hr;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String link;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String directorlink;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String hrPadding;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String linkPadding;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String linkTitle;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String linkType;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private Boolean priority;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String metricsId;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String newWindow;
	
	@Inject
	AnalyticsService analyticsService;
	
	private String dataAction;
	
	@PostConstruct
	public void init() {
		
		LOGGER.debug("Local Nav Link Details Model initialization -- START");
		
		dataAction = analyticsService.getDataIdVal(metricsId, priority);
		
		LOGGER.debug("dataAction value being set for metricsID->"+metricsId +"-->"+ dataAction);
		LOGGER.debug("Local Nav Link Details Model initialization -- END");
		
	}

	public String getBold() {
		return bold;
	}

	public String getHr() {
		return hr;
	}

	public String getLink() {
		return link;
	}

	public String getDirectorlink() {
		return directorlink;
	}

	public String getHrPadding() {
		return hrPadding;
	}

	public String getLinkPadding() {
		return linkPadding;
	}

	public String getLinkTitle() {
		return linkTitle;
	}

	public String getLinkType() {
		return linkType;
	}

	public Boolean getPriority() {
		return priority;
	}

	public String getMetricsId() {
		return metricsId;
	}

	public String getNewWindow() {
		return newWindow;
	}

	public String getDataAction() {
		return dataAction;
	}
	
	

}

package com.amica.adc.amicacom.core.services.impl;

import org.apache.felix.scr.annotations.*;
import org.apache.sling.commons.osgi.PropertiesUtil;
import org.osgi.service.component.ComponentContext;

import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.amica.adc.amicacom.core.services.AdaptiveImageService;

@Component(
        metatype = true,
        immediate = true,
        label = "Amica Adaptive Image Rendition Service Configuration"
        )
@Service(value = AdaptiveImageService.class)
@Properties(value = {
    @Property(name = "service.description", value = "Configuration for Amica Adaptive Image Rendition Services")})

public class AdaptiveImageImpl implements AdaptiveImageService {

    private static final Logger logger = LoggerFactory.getLogger(AdaptiveImageImpl.class);

    @Property(value={"540","575","720","960","1140"},unbounded = PropertyUnbounded.ARRAY, label = "Renditions", cardinality = 50, description = "The multi field for adaptive image renditions")
    private static final String IMAGE_RENDITIONS= "amica.image.renditions";
    
    private String[] rendition;
    
    @Activate
    protected void activate(@SuppressWarnings("rawtypes") final Map context) {
        this.rendition = PropertiesUtil.toStringArray(context.get(IMAGE_RENDITIONS ));
        logger.info( "Renditions {}", rendition );
    }
    
    @Modified
    protected void modified(ComponentContext context){
       this.rendition = PropertiesUtil.toStringArray(context.getProperties().get(IMAGE_RENDITIONS));
    }
    
	@Override
	public String[] getMultiString() {
		return this.rendition;
	}
}

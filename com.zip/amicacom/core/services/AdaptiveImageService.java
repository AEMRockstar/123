package com.amica.adc.amicacom.core.services;

public interface AdaptiveImageService {
	
	public String[] getMultiString();

}

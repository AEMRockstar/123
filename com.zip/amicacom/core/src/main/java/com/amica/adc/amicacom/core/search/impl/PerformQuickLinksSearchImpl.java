package com.amica.adc.amicacom.core.search.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.jcr.Session;
import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.jcr.Value;
import javax.jcr.ValueFormatException;
import javax.jcr.LoginException;

import com.amica.adc.amicacom.core.common.utils.LinkUtil;
import com.amica.adc.amicacom.core.search.SearchConfigurationService;

import org.apache.commons.lang3.StringUtils;
import org.apache.felix.scr.annotations.*;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;

import com.amica.adc.amicacom.core.search.PerformQuickLinksSearch;
import com.day.cq.commons.Externalizer;
import com.day.cq.wcm.api.Page;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.apache.sling.api.resource.ResourceResolverFactory;


@SuppressWarnings("deprecation")
@Component
@Service
public class PerformQuickLinksSearchImpl implements PerformQuickLinksSearch {
	
	private Session adminSession;

    @Reference
    private SearchConfigurationService searchConfigurationService;
    
    @Reference
    private ResourceResolverFactory resolverFactory;
    
    @Reference
    Externalizer externalizer;

    private Resource resource;
    
    private static final Logger log = LoggerFactory.getLogger(PerformQuickLinksSearchImpl.class);
   
    public PerformQuickLinksSearchImpl() {
        super();
    }

	public JSONArray performSearch(String queryTerm,
			SlingHttpServletRequest request) throws RepositoryException,
			JSONException, LoginException {
		JSONArray jsonResults = new JSONArray();
		
		try{			
			
			
			String resourcePath = searchConfigurationService.getSearchQuicklinksAdminNodePath();
                
			Map<String, Object> param = new HashMap<String, Object>();
			param.put(ResourceResolverFactory.SUBSERVICE, "searchService");
        
			ResourceResolver resourceResolver = null;
        
			resourceResolver = resolverFactory.getServiceResourceResolver(param);
			adminSession = resourceResolver.adaptTo(Session.class);
					
			if(null == adminSession)
			{
				log.info("Could not create session for user : " + resourceResolver.getUserID());
			}
        
			Resource res = resourceResolver.getResource(resourcePath);
			this.resource = res;
			Boolean keyWordExists = false;
			
			if(null == res)
			{
				log.info("Could not retrieve resource. Check permissions for path : " + resourcePath);
			}
        
			// List<Page> pages = new ArrayList<Page>();
		
			final Iterator<Resource> quickLinkListItemsResources = resource.listChildren();
			
			while (quickLinkListItemsResources.hasNext() && !keyWordExists) {
            Resource quickLinkListItemResource = quickLinkListItemsResources.next();
            Node quickLinkListItemNode = quickLinkListItemResource.adaptTo(Node.class);
            
            ValueMap quickLinkListItemValuemap = quickLinkListItemResource.adaptTo(ValueMap.class);
            
            if (quickLinkListItemNode != null) {
            	String[] commaSeperatedKeywords = quickLinkListItemValuemap.get("keyword", new String[0]);
    			String [] keyWords = commaSeperatedKeywords[0].split(",");
    					for (int i = 0; i < keyWords.length; i++) {
    						keyWordExists = checkKeywordExists(StringUtils.trim(keyWords[i]),queryTerm);
    						if (keyWordExists) {
    							jsonResults= getQuicklinkDataJSON(StringUtils.trim(keyWords[i]), quickLinkListItemNode, request);
    							keyWords=null;
    							return jsonResults;
							}
    					}
    				
                }
            else {
            		log.info("No nodes found check the content");
            	}
            }
			
			if (adminSession != null) {
				//close the session after each query
				adminSession.logout();
				adminSession = null;
			}
        
			return jsonResults;
			
		} catch (Exception e) {
			
			log.error("ERROR in quick links search" + e + e.getStackTrace().toString());
			e.printStackTrace();
			
			if (adminSession != null) {
				adminSession.logout();
				adminSession = null;
			} else {
				log.info("Session is null; can't log out!");
			}
			
			return jsonResults;
		}
	}

	public Boolean checkKeywordExists(String keyword, String queryTerm) {
		if (queryTerm.equalsIgnoreCase(keyword)) {
        	return true;
        }
		
		return false;
	}

	public JSONArray getQuicklinkDataJSON(String keyword, Node linkNode, SlingHttpServletRequest request)
			throws RepositoryException, JSONException {
		JSONArray jsonResults = new JSONArray();
		Boolean isQuicklinksMultiple = linkNode.getProperty("quicklinks").isMultiple();
		Value [] quicklinks =null;
		String quicklink = "";
		
			if (isQuicklinksMultiple){
				quicklinks = linkNode.getProperty("quicklinks").getValues();
				
			}else{
				quicklink = linkNode.getProperty("quicklinks").getString();
			}
		
		if(linkNode !=null && isQuicklinksMultiple) {
			
			JSONArray quicklinkMultiLinkResult = HandleResultSetIfMultipleLinksReturned( quicklinks, keyword, request);
			jsonResults = addtoJsonResult(jsonResults,quicklinkMultiLinkResult);
			
				
		}else if (linkNode !=null && !isQuicklinksMultiple && quicklink.length() > 0){
			JSONArray quicklinkSingleLinkResult = HandleResultSetIfOneLinkReturned( quicklink, keyword, request);
			jsonResults = addtoJsonResult(jsonResults,quicklinkSingleLinkResult);
		}
	return jsonResults;
	}

	public JSONArray addtoJsonResult(JSONArray jsonResults,
			JSONArray quicklinkMultiLinkResult) throws JSONException {
		for(int j=0 ; j < quicklinkMultiLinkResult.length() ; j++) {
			jsonResults.put(quicklinkMultiLinkResult.getJSONObject(j)) ;
		}
		return jsonResults;
	}

	public JSONArray HandleResultSetIfOneLinkReturned(String quicklink,
			String keyword, SlingHttpServletRequest request) throws JSONException {
		JSONObject jsonEachGroupResult;
		JSONArray jsonResults = new JSONArray();
		jsonEachGroupResult = new JSONObject();
		jsonEachGroupResult.put("Display", keyword );

		String subString = StringUtils.substringBetween(quicklink, "{\"", "\"}");
		String path = "" ;
		String externalURL= "" ;
		String linkType = StringUtils.substringBetween(quicklink, "\"linkType\":\"", "\"");
		String linktitle = StringUtils.substringBetween(quicklink, "\"linktitle\":\"", "\"");
		String description = StringUtils.substringBetween(quicklink, "\"description\":\"", "\"");
        String metricsId = StringUtils.substringBetween(quicklink, "\"id\":\"", "\"");

		if(	"directorList".equalsIgnoreCase(linkType) ){
			path = StringUtils.substringBetween(quicklink, "\"directLink\":\"", "\"");
            path = LinkUtil.addHtmlExtension(path);
            externalURL = externalizer.absoluteLink(request, request.getScheme(), path);
		}else if ( "link".equalsIgnoreCase(linkType) ) {
			path = StringUtils.substringBetween(quicklink, "\"directorLink\":\"", "\"");
            path = "javascript:Director.directRequest('" + path +"');";
		}

		jsonEachGroupResult.put("linktitle",linktitle);
		jsonEachGroupResult.put("links",path);
		if(externalURL != null){
			
			jsonEachGroupResult.put("externalURL", externalURL);
		}
		jsonEachGroupResult.put("description",description);
        jsonEachGroupResult.put("metricsId",metricsId);
		jsonResults.put(jsonEachGroupResult);

		subString =null;
		path = null;
		linkType=null;
		description=null;
		return jsonResults;
	}

	public JSONArray HandleResultSetIfMultipleLinksReturned(Value[] quicklinks,
			String keyword, SlingHttpServletRequest request) throws JSONException, ValueFormatException,
			RepositoryException {
		JSONObject jsonEachGroupResult;
		JSONArray jsonResults = new JSONArray();
		
		for(int i=0 ; i< quicklinks.length ; i++ ){
			jsonEachGroupResult = new JSONObject();
			jsonEachGroupResult.put("Display", keyword );
			String subString = StringUtils.substringBetween(quicklinks[i].getString(), "{\"", "\"}");
			String path = "" ;
			String externalURL= "" ;
			String linkType = StringUtils.substringBetween(quicklinks[i].getString(), "\"linkType\":\"", "\"");
			String linktitle = StringUtils.substringBetween(quicklinks[i].getString(), "\"linktitle\":\"", "\"");
			String description = StringUtils.substringBetween(quicklinks[i].getString(), "\"description\":\"", "\"");
            String metricsId = StringUtils.substringBetween(quicklinks[i].getString(), "\"id\":\"", "\"");
			
			if(	"directorList".equalsIgnoreCase(linkType) ){
				path = StringUtils.substringBetween(quicklinks[i].getString(), "\"directLink\":\"", "\"");
                path = LinkUtil.addHtmlExtension(path);
                externalURL = externalizer.absoluteLink(request, request.getScheme(), path);
            }else if ( "link".equalsIgnoreCase(linkType) ) {
				path = StringUtils.substringBetween(quicklinks[i].getString(), "\"directorLink\":\"", "\"");
                path = "javascript:Director.directRequest('" + path +"');";
			}

			jsonEachGroupResult.put("linktitle",linktitle);
			jsonEachGroupResult.put("links",path);
			if(externalURL != null){

				jsonEachGroupResult.put("externalURL", externalURL);
			}
			jsonEachGroupResult.put("description",description);
            jsonEachGroupResult.put("metricsId",metricsId);
			jsonResults.put(jsonEachGroupResult);

			subString =null;
			path = null;
			linkType=null;
			if(i>=4){
				return jsonResults;
			}
		}
		return jsonResults;
	}

}
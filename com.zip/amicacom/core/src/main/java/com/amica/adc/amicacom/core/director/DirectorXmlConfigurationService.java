package com.amica.adc.amicacom.core.director;

public interface DirectorXmlConfigurationService {

    public String getDirectorXmlPath();

}
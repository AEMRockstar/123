package com.amica.adc.amicacom.core.search;

import java.util.List;

import javax.jcr.RepositoryException;

public interface FilteredPageList {

    boolean isHiddenPagesBefore();

    boolean isHiddenPagesAfter();

    List<Page> getResultPages() throws RepositoryException;
}
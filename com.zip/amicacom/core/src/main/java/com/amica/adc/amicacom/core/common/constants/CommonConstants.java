package com.amica.adc.amicacom.core.common.constants;

public final class CommonConstants {
	
	private CommonConstants() {
		
	}
		
	public static final String DOT = ".";
	public static final String COLON = ":";
	
	public static final String EXTENSION_HTML = ".html";
	public static final String EXTENSION_PDF = ".pdf";
	public static final String EXTENSION_JSP = ".jsp";
	
	public static final String LINK_PROTOCOL_HTTP = "http";
	public static final String LINK_PROTOCOL_TEL = "tel";
	public static final String LINK_PROTOCOL_MAIL = "mailto";
	public static final String LINK_PROTOCOL_JAVASCRIPT = "javas";
	
	public static final String DIRECTOR_LINK_TYPE_TEXT = "directorLink" ;

}

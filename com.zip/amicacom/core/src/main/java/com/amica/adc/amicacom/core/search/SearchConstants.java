package com.amica.adc.amicacom.core.search;

public abstract interface SearchConstants {
	public static final String PROP_ENABLE_SYNONYMS = "enableSynonyms";
	public static final String CHARSET_PARAM_NAME = "_charset_";
	public static final String QUERY_PARAM_NAME = "q";
	public static final String START_PARAM_NAME = "start";
	public static final String COUNT_PARAM_NAME = "count";
	public static final int MAX_COUNT = 30;
	public static final int MIN_COUNT = 5;
	public static final String HTML_EXT = "html";
}

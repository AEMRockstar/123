package com.amica.adc.amicacom.core.common.enums;

public enum PageLocation {
	HEADER ("Header"),
	FOOTER ("Footer");

	private String pageSection = null;
	
	private PageLocation (String pageLocation) {
		this.pageSection = pageLocation;
	}

	public String getPageSection() {
		return pageSection;
	}
}

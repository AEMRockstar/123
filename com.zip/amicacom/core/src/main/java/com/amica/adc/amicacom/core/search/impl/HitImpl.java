package com.amica.adc.amicacom.core.search.impl;

import javax.jcr.Node;
import javax.jcr.RepositoryException;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ValueMap;

import com.amica.adc.amicacom.core.search.Hit;
import com.amica.adc.amicacom.core.search.SearchConstants;
import com.day.cq.commons.Externalizer;
import com.day.cq.commons.jcr.JcrConstants;
import com.day.cq.dam.api.Asset;
import com.day.cq.dam.api.DamConstants;
import com.day.cq.wcm.api.NameConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

final class HitImpl implements Hit {
    
    private static final Logger log = LoggerFactory
            .getLogger(HitImpl.class);

    /**
     * The underlying CQ hit.
     */
    private final com.day.cq.search.result.Hit hit;
    private SlingHttpServletRequest request;
    private final Externalizer externalizer;
    /**
     * Creates a new hit based on the given CQ <code>hit</code>.
     * 
     * @param hit
     *            the CQ hit to wrap.
     */
    HitImpl(com.day.cq.search.result.Hit hit,SlingHttpServletRequest request, Externalizer externalizer) {
        this.hit = hit;
        this.request = request;
        this.externalizer=externalizer;
    }

    /**
     * @return the default excerpt for this hit.
     * @throws javax.jcr.RepositoryException
     *             if an error occurs while building the excerpt.
     */
    @Override
    public String getExcerpt() throws RepositoryException {
        //return hit.getExcerpt();

        // Following code is the workaround solution for the issue mentioned in rally ticket DE205.
        String excerpt;
        try {
            excerpt = hit.getExcerpt();

        } catch (NegativeArraySizeException nase) {
            log.error("Failure in hit.getExcerpt", nase.getMessage());
            log.error(nase.toString());
            return StringUtils.EMPTY;
        }

        return excerpt;
    }

    /**
     * Returns an icon class postfix for this hit.
     * 
     * @return an icon class postfix for this hit.
     * @throws javax.jcr.RepositoryException
     *             if an error occurs while reading from the repository.
     */
    @Override
    public String getIconClassPostfix() throws RepositoryException {
        String url = getURL();
        int idx = url.lastIndexOf('.');
        if (idx == -1) {
            // no extension
            return "";
        }
        String ext = url.substring(idx + 1);
        return ext;
    }

    /**
     * @return the content properties on this hit.
     * @throws javax.jcr.RepositoryException
     *             if an error occurs while reading from the repository.
     */
    @Override
    public ValueMap getProperties() throws RepositoryException {
        return hit.getProperties();
    }

    /**
     * Returns the title for this hit. The returned string may contain HTML tags, which means it must not be escaped
     * when written to the response.
     * 
     * @return the title for this hit.
     * @throws javax.jcr.RepositoryException
     *             if an error occurs while reading form the repository.
     */
    @Override
    public String getTitle() throws RepositoryException {
        String excerpt = hit.getExcerpts().get(JcrConstants.JCR_TITLE);
        if (excerpt != null) {
            return excerpt;
        }
        Resource r = getPageOrAsset(hit);
        if (r != null) {
            if (isAsset(r)) {
                return getAssetMetadataValue(r, DamConstants.DC_TITLE, r.getName());
            }

            return r.getName();
        } else {
            return null;
        }
    }
    
    /**
     * Returns <code>true</code> if the given resource is either of type <code>dam:Asset</code>.
     * 
     * @param n
     *            the resource to check.
     * @return <code>true</code> if the resource represents an asset; <code>false</code> otherwise.
     * @throws javax.jcr.RepositoryException
     *             if an error occurs during the check.
     */
    private boolean isAsset(Resource r) throws RepositoryException {
        Node n = r.adaptTo(Node.class);
        return n != null && n.isNodeType(DamConstants.NT_DAM_ASSET);
    }


    @Override
    public String getDescription() throws RepositoryException {
        String excerpt = hit.getExcerpts().get(JcrConstants.JCR_DESCRIPTION);
        if (excerpt != null) {
            return excerpt;
        }

        Resource r = getPageOrAsset(hit);
        if (r != null && isAsset(r)) {
            return getAssetMetadataValue(r, DamConstants.DC_DESCRIPTION, null);
        }

        return null;
    }

    private String getAssetMetadataValue(Resource r, String propertyName, String defaultValue) {
        Asset asset = r.adaptTo(Asset.class);
        if (asset != null) {
            Object descriptionMetadata = asset.getMetadata(propertyName);
            if (descriptionMetadata != null) {
                if (descriptionMetadata instanceof Object[]) {
                    Object[] values = (Object[]) descriptionMetadata;
                    if (values.length > 0) {
                        return values[0].toString();
                    }
                }
                return descriptionMetadata.toString();
            }
        }
        return defaultValue;
    }
    
    /**
     * @return the url for this hit.
     * @throws javax.jcr.RepositoryException
     *             if an error occurs while reading from the query result.
     */
    @Override
    public String getURL() throws RepositoryException {
        Resource r = getPageOrAsset(hit);
        if (r != null) {
            String url = request.getContextPath() + r.getPath();
            if (isPage(r)) {
                url += "." + SearchConstants.HTML_EXT;
            }
            return url;
        } else {
            return "";
        }
    }

    /**
     * Returns the basepage or asset resource that contains the current hit.
     * 
     * @return the basepage or asset resource that contains the current hit.
     * @throws javax.jcr.RepositoryException
     */
    private Resource getPageOrAsset(final com.day.cq.search.result.Hit hit) throws RepositoryException {
        Resource r = hit.getResource();
        while (!isPageOrAsset(r) && r.getName().length() > 0) {
            r = r.getParent();
        }
        return r;
    }

    /**
     * Returns <code>true</code> if the given node is either of type <code>cq:Page</code>, <code>cq:PseudoPage</code>or
     * <code>dam:Asset</code>.
     * 
     * @param n
     *            the node to check.
     * @return <code>true</code> if the node represents either a basepage or an asset; <code>false</code> otherwise.
     * @throws javax.jcr.RepositoryException
     *             if an error occurs during the check.
     */
    private boolean isPageOrAsset(Resource r) throws RepositoryException {
        return isPage(r) || isAsset(r);
    }
    
    /**
     * Returns <code>true</code> if the given resource is either of type <code>cq:Page</code> or <code>cq:PseudoPage</code>.
     * 
     * @param n
     *            the resource to check.
     * @return <code>true</code> if the resource represents a basepage; <code>false</code> otherwise.
     * @throws javax.jcr.RepositoryException
     *             if an error occurs during the check.
     */
    private boolean isPage(Resource r) throws RepositoryException {
        Node n = r.adaptTo(Node.class);
        return n != null && (n.isNodeType(NameConstants.NT_PAGE) || n.isNodeType(NameConstants.NT_PSEUDO_PAGE));
    }

    @Override
    public String getExternalURL() throws RepositoryException {
        return externalizer.absoluteLink(request, request.getScheme(), getURL());
    }

    @Override
    public long getIndex() throws RepositoryException {
        return hit.getIndex();
    }

}

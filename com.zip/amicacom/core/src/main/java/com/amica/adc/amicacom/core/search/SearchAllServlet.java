package com.amica.adc.amicacom.core.search;


import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.apache.sling.api.resource.ValueMap;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
 
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import java.io.IOException;

import com.amica.adc.amicacom.core.search.impl.CoreSearchImpl;
import com.amica.adc.amicacom.core.search.impl.PerformQuickLinksSearchImpl;
import com.day.cq.commons.Externalizer;
import com.day.cq.search.QueryBuilder;

import org.apache.commons.lang3.StringUtils;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Service;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Deactivate;

import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.apache.sling.commons.json.JSONArray;

import org.apache.sling.commons.json.JSONObject;
import org.apache.sling.jcr.api.SlingRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import javax.jcr.RepositoryException;
import javax.jcr.Session;

import java.util.HashMap; 
import java.util.Map; 

import org.apache.sling.api.resource.ResourceResolver; 
import org.apache.sling.api.resource.Resource; 

@Component(service=Servlet.class,
property={
        "sling.servlet.methods=" + HttpConstants.METHOD_GET,
        "sling.servlet.resourceTypes="+ "/apps/amica-digital/components/content/search-results",
        "sling.servlet.selectors=" + "all",
        "sling.servlet.extensions=" + "json"
})


public class SearchAllServlet extends SlingSafeMethodsServlet {

    @Reference
    private QueryBuilder queryBuilder;

    @Reference
    private Externalizer externalizer;

    private String[] exclusionProperties;
    
    @Reference
    private SearchResults searchResults; 
    
	private static final long serialVersionUID = 3169795937693969416L;
	private static final Logger log = LoggerFactory
			.getLogger(SearchAllServlet.class);
		
	@Override
	public final void doGet(final SlingHttpServletRequest request,
			final SlingHttpServletResponse response) throws ServletException,
			IOException {
		response.setHeader("Content-Type", "application/json");
		
		CoreSearch coreSearch = new CoreSearchImpl(queryBuilder, externalizer, exclusionProperties, request);
		
		Result result = coreSearch.getResult();

        JSONObject jsonGroupResult;
		JSONObject jsonGroupObject = new JSONObject();
		
		JSONArray jsonResults;
		
		try {
			log.info("Hits"+result.getHits().size());
			jsonResults = searchResults.performSearchResults(result);
			
			String queryTerm = request.getParameter("q");
			
			if (StringUtils.isNotEmpty(queryTerm)) {
				
				jsonGroupResult = new JSONObject();
				
				log.info("Results found for Query Term : " + queryTerm + " are : " + jsonResults.length());
				
				jsonGroupResult.put("groupName", "Search Results");
				jsonGroupResult.put("totalMatches", result.getTotalMatches());
				
				if (jsonResults.length() > 0) {
					jsonGroupResult.put("groupResult", jsonResults);
				}
				
				if(StringUtils.isNotEmpty(result.getSpellcheck())) {
					jsonGroupResult.put("suggestion", result.getSpellcheck());
				}					
				
				jsonGroupObject.put("searchResults", jsonGroupResult);
				
				log.info("Json Object searchResults length"+ jsonGroupObject.length());

			}
		} catch (Exception e) {
			log.error("ERROR" + e + e.getStackTrace().toString());
			e.printStackTrace();
		}
		if (jsonGroupObject.length() > 0) {
			response.getWriter().print(jsonGroupObject.toString());
	}
		else {
			response.getWriter().print("empty");
		}
	}
	
	
	@Activate
	protected void activate() throws RepositoryException {
		log.info("Search Results Servlet Activated Successfully");
	}

	@Deactivate
	protected void deactivate() {
		log.info("Search Results Servlet Deactivated");
	}

}
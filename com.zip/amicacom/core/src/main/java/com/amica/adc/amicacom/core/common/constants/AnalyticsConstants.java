package com.amica.adc.amicacom.core.common.constants;

public final class AnalyticsConstants {
	
	private AnalyticsConstants() {
		
	}
		
	public static final String PRIORITY_TEXT = "cmsTrack";

}

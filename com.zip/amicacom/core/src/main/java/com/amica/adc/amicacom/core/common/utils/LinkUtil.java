package com.amica.adc.amicacom.core.common.utils;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.ResourceResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Can Altuner
 */
public final class LinkUtil {
    private static final Logger LOGGER = LoggerFactory.getLogger(LinkUtil.class);

    private static final String HTTP = "http://";
    private static final String HTTPS = "https://";
    private static final String MAILTO = "mailto:";
    private static final String TEL = "tel:";
    private static final String HTML_EXTENSION = ".html";
    private static final String PDF_EXTENSION = ".pdf";
    private static final String SLASH = "/";
    private static final String HASH = "#";

    private LinkUtil() {
        // Prevent the creation of this object as an instance.
    }

    /**
     *
     * @param path
     * @return
     */
    public static String addHtmlExtension(final String path) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("path: " + path);
        }
        final StringBuilder finalPath = new StringBuilder();
        if (StringUtils.isNotEmpty(path)
                && processPath(path)) {
            finalPath.append(path).append(HTML_EXTENSION);
        } else {
            finalPath.append(path);
        }
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("finalPath: " + finalPath);
        }
        return finalPath.toString();
    }

    /**
     *
     * @param resourceResolver
     * @param path
     * @return
     */
    public static String addHtmlExtension(final ResourceResolver resourceResolver, final String path) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("path: " + path);
        }
        final StringBuilder finalPath = new StringBuilder();
        if (StringUtils.isNotEmpty(path)
                && processPath(path)) {
            finalPath.append(resourceResolver.map(path)).append(HTML_EXTENSION);
        } else {
            finalPath.append(path);
        }
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("finalPath: " + finalPath);
        }
        return finalPath.toString();
    }

    private static boolean processPath(final String path) {
        return (!path.equals(HASH)
                && !path.startsWith(HTTP)
                && !path.startsWith(HTTPS)
                && !path.startsWith(MAILTO)
                && !path.startsWith(TEL)
                && !path.endsWith(HTML_EXTENSION)
                && !path.endsWith(PDF_EXTENSION)
                && !path.endsWith(SLASH));
    }
}
package com.amica.adc.amicacom.core.search.impl;

import java.util.List;
import javax.jcr.RepositoryException;

import com.amica.adc.amicacom.core.search.FilteredPageList;
import com.amica.adc.amicacom.core.search.Page;

final class FilteredPageListImpl implements FilteredPageList {

    private final boolean hiddenBefore;

    private final boolean hiddenAfter;

    private final List<Page> list;

    public FilteredPageListImpl(List<Page> list, boolean before, boolean after) {
        this.list = list;
        this.hiddenBefore = before;
        this.hiddenAfter = after;
    }

    @Override
    public boolean isHiddenPagesBefore() {
        return hiddenBefore;
    }

    @Override
    public boolean isHiddenPagesAfter() {
        return hiddenAfter;
    }

    @Override
    public List<Page> getResultPages() throws RepositoryException {
        return list;
    }

}
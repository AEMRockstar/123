package com.amica.adc.amicacom.core.workflow;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Service;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.sling.api.resource.ResourceResolver;
import java.util.Iterator;
import com.day.cq.commons.TidyJSONWriter;
import javax.jcr.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.apache.jackrabbit.api.JackrabbitSession;
import org.apache.jackrabbit.api.security.user.UserManager  ;
import org.apache.jackrabbit.api.security.user.User;
import org.apache.jackrabbit.api.security.user.Group;
import  org.apache.jackrabbit.api.security.user.Authorizable ;
import javax.jcr.Value;

@Component(immediate = true)
@Service
@Properties({
    @Property(name = "sling.servlet.paths", value = "/apps/amica/userlist")
}
)
public class UserListServlet extends SlingSafeMethodsServlet{
    @Override
    public final void doGet(final SlingHttpServletRequest request,
    final SlingHttpServletResponse response){
    	
    	Logger log = LoggerFactory.getLogger(UserListServlet.class);
    	log.info("In UserList Servlet");
    	
        String groupsParam = request.getParameter("groups");
        String [] groups = null;
        if(groupsParam!=null){
            groups = groupsParam.split("_");
        }
        else {
        	log.info("Group parameter value null in request.");
        }
        try {
            TidyJSONWriter tidyJSONWriter = new TidyJSONWriter(response.getWriter());
            tidyJSONWriter.array();
            if(groups!=null){
                ResourceResolver resourceResolver = request.getResourceResolver();
                for(String groupName : groups){
                	UserManager userManager ;
                	Session session=request.getResourceResolver().adaptTo(Session.class);
                    userManager = ((JackrabbitSession) session).getUserManager();
                    if(userManager != null){
                        Authorizable id = userManager.getAuthorizable(groupName);
                        if(null == id)
                        {
                        	log.info("Cannot retrieve authorizable id for group : " + groupName);
                        	
                        }
                        else
                        {
                        	tidyJSONWriter.object();
                            tidyJSONWriter.key("text").value(id.getID() +"(Group)");
                            tidyJSONWriter.key("value").value(id.getID());
                            tidyJSONWriter.endObject();
                            Group group = (Group) id;
                            Iterator <Authorizable> members = group.getMembers();
                            while(members.hasNext()){
                                Authorizable user = members.next();
                                
                                String uName = id.getID();
                                if(user.hasProperty("profile/givenName") && user.hasProperty("profile/familyName")){
                                	uName = user.getProperty("profile/givenName")[0].getString() + " " + user.getProperty("profile/familyName")[0].getString();
                                }
                                
                                if(user.hasProperty("profile/cn")){
                                	uName = user.getProperty("profile/cn")[0].getString();
                                }
                                	
                                tidyJSONWriter.object();
                                tidyJSONWriter.key("text").value( uName + " ( from group "+ id.getID()+ " )");
                                tidyJSONWriter.key("value").value(user.getID());
                                tidyJSONWriter.endObject();
                            }
                        }
                    }
                    else
                    {
                    	log.info("Cannot retrieve UserManager.");
                    }
                }
            }
            tidyJSONWriter.endArray();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
}


package com.amica.adc.amicacom.core.search;

public interface Page {

    long getIndex();

    String getURL();

    boolean isCurrentPage();

}
package com.amica.adc.amicacom.core.services;

public interface AnalyticsService {
		
	public String getDataIdVal(String metricsId, Boolean priority);
	
	public String getDataIdVal(String pageLocation, String metricsId, Boolean priority);

	public String getDataIdVal(String pageName, String category, String metricsId, Boolean priority);
	
}

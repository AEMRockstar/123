package com.amica.adc.amicacom.core.models;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import com.amica.adc.amicacom.core.services.AnalyticsService;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Model ( adaptables = Resource.class)
public class TextImageModel {
	
	public static final Logger LOGGER = LoggerFactory.getLogger(TextImageModel.class);
	
	@SlingObject
	Resource resource;
	
	@Inject @Optional
	private String metricsId;
	
	@Inject @Optional
	private Boolean priority;
	
	@Inject
	AnalyticsService analyticsService;
	
	private String dataAction;
	
	@PostConstruct
	public void init() {
		
		LOGGER.debug("Text Image Model initialization -- START");
		
		dataAction = analyticsService.getDataIdVal(metricsId, priority);

		LOGGER.debug("Text Image Model initialization -- END");
		
	}

	public String getDataAction() {
		return dataAction;
	}
	
}

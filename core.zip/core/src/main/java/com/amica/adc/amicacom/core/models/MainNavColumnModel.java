package com.amica.adc.amicacom.core.models;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import com.amica.adc.amicacom.core.common.enums.PageLocation;
import com.amica.adc.amicacom.core.models.LinkListModel;
import com.amica.adc.amicacom.core.services.AnalyticsService;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceUtil;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Model ( adaptables = Resource.class)
public class MainNavColumnModel {
	
	public static final Logger LOGGER = LoggerFactory.getLogger(MainNavColumnModel.class);
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String metricsId;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private Boolean priority;
	
	@Inject @Optional
	private Resource items1;
	
	@Inject @Optional
	private Resource items2;
	
	@Inject @Optional
	private Resource items3;
	
	@Inject @Optional
	private Resource items4;
	
	@OSGiService
	AnalyticsService analyticsService;
	
	private String dataAction;	

	private List<MainNavLinkDetailsModel> links1 = new ArrayList<MainNavLinkDetailsModel>();
	private List<MainNavLinkDetailsModel> links2 = new ArrayList<MainNavLinkDetailsModel>();
	private List<MainNavLinkDetailsModel> links3 = new ArrayList<MainNavLinkDetailsModel>();
	private List<MainNavLinkDetailsModel> links4 = new ArrayList<MainNavLinkDetailsModel>();
	
	@PostConstruct
	public void init() {
		
		LOGGER.debug("Main Nav Column Model initialization -- START");
		
		if(StringUtils.isNotEmpty(metricsId)) {
			
			dataAction = analyticsService.getDataIdVal(PageLocation.HEADER.getPageSection(), metricsId, priority);
		}
		
		//Rewrite this code block ## START
		
		if(items1!= null && !ResourceUtil.isNonExistingResource(items1) && items1.hasChildren()) {
			LOGGER.debug("Child resources present");
			Iterator<Resource> iterator = items1.listChildren();
				while(iterator.hasNext()){
					Resource childLinkResource = iterator.next();
					MainNavLinkDetailsModel item = childLinkResource.adaptTo(MainNavLinkDetailsModel.class);
					
					LOGGER.debug("item-dataaction value-->"+item.getDataAction());
					links1.add(item);
					
				}
		}
		
		if(items2!= null && !ResourceUtil.isNonExistingResource(items2) && items2.hasChildren()) {
			LOGGER.debug("Child resources present");
			Iterator<Resource> iterator = items2.listChildren();
				while(iterator.hasNext()){
					Resource childLinkResource = iterator.next();
					MainNavLinkDetailsModel item = childLinkResource.adaptTo(MainNavLinkDetailsModel.class);
					
					LOGGER.debug("item-dataaction value-->"+item.getDataAction());
					links2.add(item);
					
				}
		}
		
		if(items3!= null && !ResourceUtil.isNonExistingResource(items3) && items3.hasChildren()) {
			LOGGER.debug("Child resources present");
			Iterator<Resource> iterator = items3.listChildren();
				while(iterator.hasNext()){
					Resource childLinkResource = iterator.next();
					MainNavLinkDetailsModel item = childLinkResource.adaptTo(MainNavLinkDetailsModel.class);
					
					LOGGER.debug("item-dataaction value-->"+item.getDataAction());
					links3.add(item);
					
				}
		}
		
		if(items4!= null && !ResourceUtil.isNonExistingResource(items4) && items4.hasChildren()) {
			LOGGER.debug("Child resources present");
			Iterator<Resource> iterator = items4.listChildren();
				while(iterator.hasNext()){
					Resource childLinkResource = iterator.next();
					MainNavLinkDetailsModel item = childLinkResource.adaptTo(MainNavLinkDetailsModel.class);
					
					LOGGER.debug("item-dataaction value-->"+item.getDataAction());
					links4.add(item);
					
				}
		}
		
		//Rewrite this code block ## STOP
		
		LOGGER.debug(" Main Nav Column Model initialization -- END");
	}


	public Resource getItemsIn() {
		return items1;
	}

	
	public String getDataAction() {
		return dataAction;
	}


	public List<MainNavLinkDetailsModel> getLinks1() {
		return links1;
	}


	public List<MainNavLinkDetailsModel> getLinks2() {
		return links2;
	}


	public List<MainNavLinkDetailsModel> getLinks3() {
		return links3;
	}


	public List<MainNavLinkDetailsModel> getLinks4() {
		return links4;
	}
	
}

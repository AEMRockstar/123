package com.amica.adc.amicacom.core.services.impl;

import org.apache.commons.lang3.StringUtils;
import org.osgi.service.component.annotations.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.amica.adc.amicacom.core.common.constants.AnalyticsConstants;
import com.amica.adc.amicacom.core.common.constants.CommonConstants;
import com.amica.adc.amicacom.core.common.enums.PageLocation;
import com.amica.adc.amicacom.core.services.AnalyticsService;

@Component(service={AnalyticsService.class}, immediate=true)
public class AnalyticsServiceImpl implements AnalyticsService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(AnalyticsServiceImpl.class);
	
	@Override
	public String getDataIdVal(String metricsId, Boolean priority) {
		String dataId = null;
		if(StringUtils.isNotEmpty(metricsId)) {
			dataId = metricsId + ((priority!=null && priority) ? CommonConstants.DOT + AnalyticsConstants.PRIORITY_TEXT : "");
		}
		LOGGER.debug("dataID value being set::"+ dataId);
		
		return dataId;
	}
	
	public String getDataIdVal(String pageLocation, String metricsId, Boolean priority) {
		
		String dataId = null;
		
		if(StringUtils.isNotEmpty(pageLocation.toString())) {
			dataId = pageLocation + CommonConstants.COLON + getDataIdVal(metricsId, priority);
		}
		LOGGER.debug("dataID value being set with pageLocation::"+ dataId);
		
		return dataId;
	}
	
	public String getDataIdVal(String pageName, String category, String metricsId, Boolean priority) {
		
		String dataId = getDataIdVal(metricsId, priority);
				
		return dataId;
	}

}

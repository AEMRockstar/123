package com.amica.adc.amicacom.core.models;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import com.amica.adc.amicacom.core.common.constants.CommonConstants;
import com.amica.adc.amicacom.core.common.constants.SearchConstants;
import com.amica.adc.amicacom.core.search.SearchConfigurationService;
import com.amica.adc.amicacom.core.services.AnalyticsService;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Model ( adaptables = Resource.class)
public class SearchResultsModel {
	
	public static final Logger LOGGER = LoggerFactory.getLogger(SearchResultsModel.class);
	
	@SlingObject
	Resource resource;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String suggestionText;
	
	@Inject
	SearchConfigurationService searchConfigService;
	
	private String searchResultResourceNode;
	private String searchResultPagePath;
		
	@PostConstruct
	public void init() {
		
		LOGGER.debug("Search Result  Model initialization -- START");
		
		searchResultPagePath = searchConfigService.getSearchResultsPagePath();
		searchResultResourceNode = searchConfigService.getSearchResultsResourceNodePath();
		
		LOGGER.debug("Search Result Model initialization -- END");
		
	}


	public String getSearchResultResourceNode() {
		searchResultResourceNode += CommonConstants.DOT + SearchConstants.SEARCH_SERVLET_SELECTOR +
				CommonConstants.DOT + SearchConstants.SEARCH_SERVLET_EXTENSION;
		return searchResultResourceNode;
	}


	public String getSuggestionText() {
		return suggestionText;
	}


	public String getSearchResultPagePath() {
		return searchResultPagePath;
	}
	
}

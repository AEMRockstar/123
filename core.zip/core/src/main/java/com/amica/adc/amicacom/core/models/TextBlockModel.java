package com.amica.adc.amicacom.core.models;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import com.amica.adc.amicacom.core.services.AnalyticsService;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Model ( adaptables = Resource.class)
public class TextBlockModel {
	
	public static final Logger LOGGER = LoggerFactory.getLogger(TextBlockModel.class);
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String title;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String bodyText;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String linkText;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String linkType;	
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String newWindow;
	
	@Inject @Optional
	private String metricsId;
	
	@Inject @Optional
	private Boolean priority;
	
	@Inject
	AnalyticsService analyticsService;
	
	private String dataAction;
	
	@PostConstruct
	public void init() {
		
		LOGGER.debug("TextBlock Model initialization -- START");
		
		dataAction = analyticsService.getDataIdVal(metricsId, priority);

		LOGGER.debug("TextBlock Model initialization -- END");
		
	}
	
	public String getDataAction() {
		return dataAction;
	}
	
	public String getBodyText() {
		return bodyText;
	}

	public String getTitle() {
		return title;
	}

	public String getLinkType() {
		return linkType;
	}
	
	public String getLinkText() {
		return linkText;
	}

	public String getNewWindow() {
		return newWindow;
	}
	
}

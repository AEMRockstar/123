package com.amica.adc.amicacom.core.director.impl;

import org.apache.felix.scr.annotations.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.amica.adc.amicacom.core.director.DirectorXmlConfigurationService;

import org.osgi.service.component.ComponentContext;


@Component(
        metatype = true,
        immediate = true,
        label = "Amica Director XML Services Configuration",
        description = "Configuration path of Amica Director XML"
        )
@Service(value = DirectorXmlConfigurationService.class)
@Properties(value = {
    @Property(name = "service.description", value = "Configuration path of Amica Director XML")})

public class DirectorXmlConfigurationServiceImpl implements  DirectorXmlConfigurationService {

    private static final Logger logger = LoggerFactory.getLogger(DirectorXmlConfigurationServiceImpl.class);
    
    @Property(label = "path of Amica Director XML", description = "Configuration path of Amica Director XML.", propertyPrivate = false, value = "http://www.amica.com/director/director.xml")
	private static final String AMICA_DIRECTOR_XML_PATH = "amica.director.xml.path";
	   
    
    private String directorXmlpath;
    
    @Activate
    @Modified
    protected void activate(ComponentContext ctx) {

         if( ctx.getProperties().get( AMICA_DIRECTOR_XML_PATH ) != null ){
        	 directorXmlpath = (String) ctx.getProperties().get( AMICA_DIRECTOR_XML_PATH );
            logger.info( "path of Amica Director XML {}", directorXmlpath );
        }
    }
	
    public String getDirectorXmlPath() {
        return directorXmlpath;
    }

}
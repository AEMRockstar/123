package com.amica.adc.amicacom.core.common.constants;

public final class SearchConstants {
	
	private SearchConstants() {
		
	}
		
	public static final String SEARCH_SERVLET_SELECTOR = "all";
	public static final String SEARCH_SERVLET_EXTENSION = "json";

}

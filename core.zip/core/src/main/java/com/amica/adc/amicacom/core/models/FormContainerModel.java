package com.amica.adc.amicacom.core.models;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import com.amica.adc.amicacom.core.common.constants.CommonConstants;
import com.amica.adc.amicacom.core.common.constants.SearchConstants;
import com.amica.adc.amicacom.core.search.SearchConfigurationService;
import com.amica.adc.amicacom.core.services.AnalyticsService;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Model ( adaptables = Resource.class)
public class FormContainerModel {
	
	public static final Logger LOGGER = LoggerFactory.getLogger(FormContainerModel.class);
	
	@SlingObject
	Resource resource;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String action;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String formId;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String formTitle;
	
		
	@PostConstruct
	public void init() {
		
		LOGGER.debug("Form Container  Model initialization -- START");
		
	}

	public String getAction() {
		return action;
	}

	public String getFormId() {
		return formId;
	}
	
	public String getFormTitle() {
		return formTitle;
	}

	
}

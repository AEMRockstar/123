package com.amica.adc.amicacom.core.search.impl;

import org.apache.felix.scr.annotations.Activate;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.PropertyUnbounded;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.adapter.AdapterFactory;
import org.apache.sling.commons.osgi.PropertiesUtil;
import org.osgi.service.component.ComponentContext;

import com.amica.adc.amicacom.core.search.CoreSearch;
import com.day.cq.commons.Externalizer;
import com.day.cq.search.QueryBuilder;


@Component(metatype = true, label = "Amica Core Search Adapter Factory",
        description = "Component which creates Amica CoreSearch implementations.")
@Service
@Properties({
        @Property(name = AdapterFactory.ADAPTABLE_CLASSES, value = "org.apache.sling.api.SlingHttpServletRequest", propertyPrivate = true),
        @Property(name = AdapterFactory.ADAPTER_CLASSES, value = "com.amica.adc.amicacom.core.search.CoreSearch", propertyPrivate = true) })
public class CoreSearchAdapterFactory implements AdapterFactory {

    private static final String[] DEFAULT_EXCLUSION_PROPERTIES = { "jcr:content/hideInSearch", "jcr:content/metadata/hideInSearch"  };

    @Property(
            value = { "jcr:content/hideInSearch" },
            unbounded = PropertyUnbounded.ARRAY,
            label = "Exclusion Properties",
            description = "Set of properties which will indicate that a basepage or asset should be excluded from search results.")
    private static final String PROP_EXCLUSION_PROPERTIES = "exclusion.properties";

    @Reference
    private QueryBuilder queryBuilder;

    @Reference
    private Externalizer externalizer;

    private String[] exclusionProperties;

    @Activate
    protected void activate(ComponentContext ctx) {
        this.exclusionProperties = PropertiesUtil.toStringArray(
                ctx.getProperties().get(PROP_EXCLUSION_PROPERTIES), DEFAULT_EXCLUSION_PROPERTIES);
    }

    @SuppressWarnings("unchecked")
    public <AdapterType> AdapterType getAdapter(Object adaptable, Class<AdapterType> type) {
        if (type == CoreSearch.class && adaptable instanceof SlingHttpServletRequest) {
            return (AdapterType) new CoreSearchImpl(queryBuilder, externalizer, exclusionProperties,
                    (SlingHttpServletRequest) adaptable);
        }
        return null;
    }

}

package com.amica.adc.amicacom.core.models;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import com.amica.adc.amicacom.core.services.AnalyticsService;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Model ( adaptables = Resource.class)
public class TestimonialModel {
	
	public static final Logger LOGGER = LoggerFactory.getLogger(TestimonialModel.class);
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String textArea;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String textField;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String icon;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String linkType;	
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String newWindow;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String alt;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String tooltip;

	@Inject @Optional
	private String metricsId;
	
	@Inject @Optional
	private Boolean priority;
	
	@Inject
	AnalyticsService analyticsService;
	
	private String dataAction;
	
	@PostConstruct
	public void init() {
		
		LOGGER.debug("Testimonial Model initialization -- START");
		
		dataAction = analyticsService.getDataIdVal(metricsId, priority);

		LOGGER.debug("Testimonial Model initialization -- END");
		
	}

	public String getDataAction() {
		return dataAction;
	}
	
	public String getTextArea() {
		return textArea;
	}

	public String getTextField() {
		return textField;
	}

	public String getLinkType() {
		return linkType;
	}

	public String getNewWindow() {
		return newWindow;
	}	

	public String getAlt() {
		return alt;
	}

	public String getTooltip() {
		return tooltip;
	}

	public String getIcon() {
		return icon;
	}
	
	
	
}

package com.amica.adc.amicacom.core.models;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import com.amica.adc.amicacom.core.services.AnalyticsService;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Model ( adaptables = Resource.class)
public class GetAQuoteModel {
	
	public static final Logger LOGGER = LoggerFactory.getLogger(GetAQuoteModel.class);
	
	@SlingObject
	Resource resource;
	
	@Inject @Optional
	private String metricsId;
	
	@Inject @Optional
	private Boolean priority;
	
	@Inject @Optional
	private String metricsIdQuoteInfo;
	
	@Inject @Optional
	private Boolean priorityQuoteInfo;
	
	@Inject @Optional
	private String metricsIdRetriveInfo;
	
	@Inject @Optional
	private Boolean priorityRetriveInfo;
	
	@Inject
	AnalyticsService analyticsService;
	
	private String dataAction;
	
	private String dataActionQuoteInfo;
	
	private String dataActionRetriveInfo;
	
	@PostConstruct
	public void init() {
		
		LOGGER.debug("GetAQuote Model initialization -- START");
		
		dataAction = analyticsService.getDataIdVal(metricsId, priority);
		
		dataActionQuoteInfo = analyticsService.getDataIdVal(metricsIdQuoteInfo, priorityQuoteInfo);
		
		dataActionRetriveInfo = analyticsService.getDataIdVal(metricsIdRetriveInfo, priorityRetriveInfo);
		
		LOGGER.debug("GetAQuote Model initialization -- END");
		
	}
	
	public String getMetricsId() {
		return metricsId;
	}

	public Boolean getPriority() {
		return priority;
	}


	public String getDataAction() {
		return dataAction;
	}
	
	public String getMetricsIdQuoteInfo() {
		return metricsIdQuoteInfo;
	}

	public Boolean getPriorityQuoteInfo() {
		return priorityQuoteInfo;
	}


	public String getDataActionQuoteInfo() {
		return dataActionQuoteInfo;
	}
	
	public String getMetricsIdRetriveInfo() {
		return metricsIdRetriveInfo;
	}

	public Boolean getPriorityRetriveInfo() {
		return priorityRetriveInfo;
	}


	public String getDataActionRetriveInfo() {
		return dataActionRetriveInfo;
	}
	
}

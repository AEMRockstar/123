package com.amica.adc.amicacom.core.director;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Service;
import org.apache.felix.scr.annotations.Properties;
import org.apache.felix.scr.annotations.Property;
import org.osgi.service.component.ComponentContext;
import org.apache.felix.scr.annotations.*;
import com.amica.adc.amicacom.core.director.DirectorXmlConfigurationService;

@Component(immediate = true)
@Service
@Properties({ @Property(name = "sling.servlet.paths", value = "/bin/amica/directorxml") })
public class DirectorXmlServlet extends SlingSafeMethodsServlet {
	 @Reference
	    private DirectorXmlConfigurationService directorXmlConfigurationService;
	
	@Override
	public final void doGet(final SlingHttpServletRequest request,
			final SlingHttpServletResponse response) {
			response.setContentType("text/xml");
		try {
			HttpClient httpclient = new HttpClient();
		    GetMethod get = new GetMethod(directorXmlConfigurationService.getDirectorXmlPath());
		    get.setRequestHeader("Content-Type", "text/xml");
		    httpclient.executeMethod(get);
		    response.getWriter().print(get.getResponseBodyAsString());

		} catch (Exception e) {
			
			e.printStackTrace();
		}
	}

}
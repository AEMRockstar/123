package com.amica.adc.amicacom.core.models;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import com.amica.adc.amicacom.core.services.AnalyticsService;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Model ( adaptables = Resource.class)
public class EmbeddedVideoModel {
	
	public static final Logger LOGGER = LoggerFactory.getLogger(EmbeddedVideoModel.class);
	
	@SlingObject
	Resource resource;
	
	@Inject @Optional
	private String metricsId;
	
	@Inject @Optional
	private Boolean priority;
	
	@Inject
	AnalyticsService analyticsService;
	
	private String dataAction;
	
	@PostConstruct
	public void init() {
		
		LOGGER.debug("Button Model initialization -- START");
		
		dataAction = analyticsService.getDataIdVal(metricsId, priority);

		LOGGER.debug("Button Model initialization -- END");
		
	}

	public String getDataAction() {
		return dataAction;
	}
	
}

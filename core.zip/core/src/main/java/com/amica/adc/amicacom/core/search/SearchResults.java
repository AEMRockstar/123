package com.amica.adc.amicacom.core.search;

import javax.jcr.RepositoryException;

import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;

@SuppressWarnings("deprecation")
public interface SearchResults {

	JSONArray performSearchResults(Result result) throws RepositoryException, JSONException;

	
}

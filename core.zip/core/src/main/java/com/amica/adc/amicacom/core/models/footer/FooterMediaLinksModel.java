package com.amica.adc.amicacom.core.models.footer;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import com.amica.adc.amicacom.core.common.enums.PageLocation;
import com.amica.adc.amicacom.core.models.LinkListModel;
import com.amica.adc.amicacom.core.services.AnalyticsService;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceUtil;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;
import org.apache.sling.models.annotations.injectorspecific.InjectionStrategy;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Model ( adaptables = Resource.class)
public class FooterMediaLinksModel {
	
	public static final Logger LOGGER = LoggerFactory.getLogger(FooterMediaLinksModel.class);
	
	@Inject @Optional
	private Resource itemsIn;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private String metricsId;
	
	@ValueMapValue(injectionStrategy = InjectionStrategy.OPTIONAL)
	private Boolean priority;
	
	@OSGiService
	AnalyticsService analyticsService;

	private List<LinkListModel> links = new ArrayList<LinkListModel>();
	
	private String dataAction;	
	
	@PostConstruct
	public void init() {
		
		LOGGER.debug("Footer Media links Model initialization -- START");
		
		if(StringUtils.isNotEmpty(metricsId)) {
			
			dataAction = analyticsService.getDataIdVal(PageLocation.FOOTER.getPageSection(), metricsId, priority);
		}
		
		if(itemsIn!=null && !ResourceUtil.isNonExistingResource(itemsIn) && itemsIn.hasChildren()) {
			LOGGER.debug("Child resources present");
			Iterator<Resource> iterator = itemsIn.listChildren();
				while(iterator.hasNext()){
					Resource childLinkResource = iterator.next();
					LinkListModel item = childLinkResource.adaptTo(LinkListModel.class);
					
					LOGGER.debug("item-dataaction value-->"+item.getDataAction());
					links.add(item);
					
				}
		}
		
		LOGGER.debug("Footer Media links Model -- END");
	}


	public Resource getItemsIn() {
		return itemsIn;
	}


	public List<LinkListModel> getLinks() {
		return links;
	}


	public String getMetricsId() {
		return metricsId;
	}


	public Boolean getPriority() {
		return priority;
	}
	
	public String getDataAction() {
		return dataAction;
	}
	
}

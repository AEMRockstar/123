package com.amica.adc.amicacom.core.search.impl;

import java.util.List;
import javax.jcr.RepositoryException;

import org.apache.commons.lang3.StringUtils;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Service;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.amica.adc.amicacom.core.search.Result;
import com.amica.adc.amicacom.core.search.SearchResults;
import com.amica.adc.amicacom.core.search.Hit;

@SuppressWarnings("deprecation")
@Component
@Service
public class SearchResultsImpl implements SearchResults{
	
	private static final Logger log = LoggerFactory.getLogger(SearchResultsImpl.class);
   
    public SearchResultsImpl() {
        super();
    }

	public JSONArray performSearchResults(Result result)
			throws RepositoryException, JSONException {
    	
		JSONArray jsonResults = new JSONArray();
		JSONObject jsonEachGroupResult;
		
		List<Hit> resultList  = result.getHits();
		
		log.info("Result List Size" + resultList.size());
		
		if (!resultList.isEmpty()) {
	        for (final Hit hit : resultList) {
	        	final String url = hit.getURL();
	        	final String title = hit.getTitle();
	        	final String excerpt = hit.getExcerpt(); 
	        	final String description = hit.getDescription();
	        	final String externalUrl = hit.getExternalURL();

	        	
	        	
	        	jsonEachGroupResult = new JSONObject();
				jsonEachGroupResult.put("title", title );
				
				if(excerpt != null){
		        	final String dispalyExcerpt = displayExcerpt(excerpt); 		        	
		        	jsonEachGroupResult.put("excerpt", dispalyExcerpt );
				}
				if(description !=null){	        		
		        		final String displayDescription = displayDescription(description);		        	
						jsonEachGroupResult.put("description", displayDescription );
					}					
				
				jsonEachGroupResult.put("URL", url );
				jsonEachGroupResult.put("externalURL", externalUrl );
				jsonResults.put(jsonEachGroupResult);
	        	}
			} else {
			
    		log.info("No result pages for the full text search");
    	}
		return jsonResults;
	}

	private String displayExcerpt(String excerpt) throws RepositoryException {
			if (isExcerptWithTag(excerpt)){
				excerpt = StringUtils.substringBefore(excerpt, "<a");
			}
			if (isExcerptWithDots(excerpt)){
				excerpt = StringUtils.replace(excerpt, "...", "");
			}
			excerpt = excerpt.trim();
		return excerpt;
	}

	private String displayDescription(String description) {
			description = description.trim();
		return description;
	}
	
	private boolean isExcerptWithTag(String excerpt) throws RepositoryException {
		 boolean excerptCheck = StringUtils.contains(excerpt, "<a");
		 return excerptCheck;
	}
	
	private boolean isExcerptWithDots(String excerpt) throws RepositoryException {
		Boolean dotsCheck = StringUtils.contains(excerpt, "...");
		 return dotsCheck;
	} 
	
}
